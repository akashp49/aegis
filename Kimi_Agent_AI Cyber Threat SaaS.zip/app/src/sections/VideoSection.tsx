import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

export default function VideoSection() {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!containerRef.current) return

    const ctx = gsap.context(() => {
      gsap.fromTo(
        containerRef.current,
        { opacity: 0, y: 60 },
        {
          opacity: 1,
          y: 0,
          duration: 1.0,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: containerRef.current,
            start: 'top 80%',
          },
        }
      )
    })

    return () => ctx.revert()
  }, [])

  return (
    <section style={{ position: 'relative', zIndex: 2, background: '#050508' }}>
      <div
        className="mx-auto"
        style={{
          maxWidth: '1200px',
          padding: '160px 24px 140px',
        }}
      >
        <div ref={containerRef}>
          <div
            style={{
              borderRadius: '8px',
              overflow: 'hidden',
              border: '1px solid rgba(255,255,255,0.06)',
              boxShadow: '0 20px 80px rgba(0,0,0,0.5)',
            }}
          >
            <video
              src="/assets/vid-1.mp4"
              autoPlay
              muted
              loop
              playsInline
              style={{
                width: '100%',
                display: 'block',
                aspectRatio: '16/9',
                objectFit: 'cover',
              }}
            />
          </div>
          <div
            className="flex justify-between items-center"
            style={{ marginTop: '20px' }}
          >
            <span
              style={{
                fontFamily: 'var(--font-sans)',
                fontSize: '14px',
                color: '#6B6B80',
              }}
            >
              Real-time threat detection across your AI infrastructure.
            </span>
            <span
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '12px',
                color: '#6B6B80',
              }}
            >
              Aegis Platform v3.2
            </span>
          </div>
        </div>
      </div>
    </section>
  )
}
