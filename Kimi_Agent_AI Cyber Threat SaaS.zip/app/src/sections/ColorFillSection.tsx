import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

interface LineData {
  text: string
  accent?: boolean
  accentColor?: string
}

interface ColorFillSectionProps {
  id: string
  lines: LineData[]
  showCta?: boolean
}

export default function ColorFillSection({ id, lines, showCta = false }: ColorFillSectionProps) {
  const sectionRef = useRef<HTMLDivElement>(null)
  const linesRef = useRef<HTMLDivElement[]>([])
  const ctaRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!sectionRef.current) return

    const ctx = gsap.context(() => {
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: '+=150%',
          pin: true,
          scrub: true,
        },
      })

      linesRef.current.forEach((line, i) => {
        if (!line) return
        const topLayer = line.querySelector('.top-layer') as HTMLElement
        if (topLayer) {
          tl.fromTo(
            topLayer,
            { clipPath: 'inset(0 100% 0 0)' },
            { clipPath: 'inset(0 0% 0 0)', ease: 'none' },
            i * 0.15
          )
        }
      })

      if (showCta && ctaRef.current) {
        tl.fromTo(
          ctaRef.current,
          { opacity: 0, y: 20 },
          { opacity: 1, y: 0, ease: 'none' },
          0.8
        )
      }
    })

    return () => ctx.revert()
  }, [showCta])

  return (
    <section
      id={id}
      ref={sectionRef}
      className="flex items-center justify-center"
      style={{
        minHeight: '100vh',
        background: '#050508',
        position: 'relative',
        zIndex: 2,
      }}
    >
      <div
        className="flex flex-col items-center"
        style={{ maxWidth: '1000px', padding: '0 24px' }}
      >
        {lines.map((line, i) => (
          <div
            key={i}
            ref={(el) => {
              if (el) linesRef.current[i] = el
            }}
            className="color-line"
            style={{
              position: 'relative',
              marginBottom: '0.2em',
              width: '100%',
              textAlign: 'center',
            }}
          >
            {/* Bottom layer (dark) */}
            <div
              style={{
                fontFamily: 'var(--font-sans)',
                fontSize: 'clamp(2rem, 6vw, 4rem)',
                fontWeight: 400,
                lineHeight: 1.15,
                color: '#1A1A24',
              }}
              aria-hidden="true"
            >
              {line.text}
            </div>
            {/* Top layer (fill color) */}
            <div
              className="top-layer"
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                width: '100%',
                fontFamily: 'var(--font-sans)',
                fontSize: 'clamp(2rem, 6vw, 4rem)',
                fontWeight: 400,
                lineHeight: 1.15,
                color: line.accent ? line.accentColor : '#E8E8F0',
                clipPath: 'inset(0 100% 0 0)',
              }}
            >
              {line.text}
            </div>
          </div>
        ))}

        {showCta && (
          <div
            ref={ctaRef}
            className="opacity-0"
            style={{ marginTop: '60px' }}
          >
            <button
              className="transition-all duration-200 cursor-pointer"
              style={{
                borderRadius: '80px',
                background: '#00F0FF',
                color: '#050508',
                padding: '16px 32px',
                fontFamily: 'var(--font-sans)',
                fontSize: '16px',
                fontWeight: 400,
                border: 'none',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = '#33F3FF'
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = '#00F0FF'
              }}
            >
              Start Your Free Trial
            </button>
          </div>
        )}
      </div>
    </section>
  )
}
