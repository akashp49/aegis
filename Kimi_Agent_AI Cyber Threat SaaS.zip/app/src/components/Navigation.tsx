import { useRef, useEffect } from 'react'
import gsap from 'gsap'

interface NavigationProps {
  onNavigate: (target: string) => void
}

export default function Navigation({ onNavigate }: NavigationProps) {
  const navRef = useRef<HTMLElement>(null)

  useEffect(() => {
    if (!navRef.current) return
    gsap.fromTo(
      navRef.current,
      { opacity: 0, y: -10 },
      { opacity: 1, y: 0, duration: 0.6, delay: 0.1, ease: 'power3.out' }
    )
  }, [])

  const navLinks = [
    { label: 'Platform', target: '#features' },
    { label: 'Threats', target: '#manifesto' },
    { label: 'Research', target: '#stats' },
    { label: 'Pricing', target: '#cta' },
  ]

  return (
    <nav
      ref={navRef}
      className="fixed top-0 left-0 w-full z-[1000] opacity-0"
      style={{
        background: 'rgba(5, 5, 8, 0.85)',
        backdropFilter: 'blur(12px)',
        WebkitBackdropFilter: 'blur(12px)',
        borderBottom: '1px solid rgba(255,255,255,0.04)',
        height: '64px',
      }}
    >
      <div className="mx-auto flex items-center justify-between h-full" style={{ maxWidth: '1200px', padding: '0 24px' }}>
        {/* Logo */}
        <button
          onClick={() => onNavigate('#hero')}
          className="flex items-center gap-2 bg-transparent border-none cursor-pointer"
        >
          <span
            className="inline-block rounded-full"
            style={{
              width: '6px',
              height: '6px',
              backgroundColor: '#00F0FF',
            }}
          />
          <span
            className="tracking-[0.15em] uppercase"
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '14px',
              color: '#E8E8F0',
            }}
          >
            AEGIS
          </span>
        </button>

        {/* Center Nav Links */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <button
              key={link.label}
              onClick={() => onNavigate(link.target)}
              className="bg-transparent border-none cursor-pointer transition-colors duration-250"
              style={{
                fontFamily: 'var(--font-sans)',
                fontSize: '14px',
                color: '#6B6B80',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.color = '#E8E8F0'
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.color = '#6B6B80'
              }}
            >
              {link.label}
            </button>
          ))}
        </div>

        {/* CTA */}
        <button
          className="transition-all duration-200 cursor-pointer"
          style={{
            borderRadius: '80px',
            background: 'rgba(255,255,255,0.06)',
            border: '1px solid rgba(255,255,255,0.08)',
            color: '#E8E8F0',
            padding: '8px 20px',
            fontFamily: 'var(--font-sans)',
            fontSize: '13px',
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = 'rgba(255,255,255,0.1)'
            e.currentTarget.style.borderColor = 'rgba(255,255,255,0.15)'
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = 'rgba(255,255,255,0.06)'
            e.currentTarget.style.borderColor = 'rgba(255,255,255,0.08)'
          }}
        >
          Get Started
        </button>
      </div>
    </nav>
  )
}
