import { useCallback } from 'react'
import { useLenis } from './hooks/useLenis'
import CRTMonitor from './components/CRTMonitor'
import Navigation from './components/Navigation'
import HeroSection from './sections/HeroSection'
import VideoSection from './sections/VideoSection'
import ColorFillSection from './sections/ColorFillSection'
import FeaturesSection from './sections/FeaturesSection'
import MarqueeGridSection from './sections/MarqueeGridSection'
import TestimonialsSection from './sections/TestimonialsSection'
import FooterSection from './sections/FooterSection'

function App() {
  const lenisRef = useLenis()

  const handleNavigate = useCallback((target: string) => {
    const lenis = lenisRef.current
    if (!lenis) return

    if (target === '#hero') {
      lenis.scrollTo(0, { duration: 1.2 })
    } else {
      const el = document.querySelector(target)
      if (el) {
        lenis.scrollTo(el as HTMLElement, { duration: 1.2 })
      }
    }
  }, [lenisRef])

  return (
    <div style={{ background: '#050508', minHeight: '100vh' }}>
      <CRTMonitor />
      <Navigation onNavigate={handleNavigate} />

      <main>
        <HeroSection />
        <VideoSection />

        {/* Manifesto Section */}
        <ColorFillSection
          id="manifesto"
          lines={[
            { text: 'AI agents are now' },
            { text: 'the primary attack' },
            { text: 'vector.', accent: true, accentColor: '#00F0FF' },
          ]}
        />

        <FeaturesSection />

        {/* Stats Section */}
        <ColorFillSection
          id="stats"
          lines={[
            { text: '88% of enterprises' },
            { text: 'had AI agent' },
            { text: 'breaches in 2025.', accent: true, accentColor: '#FF3860' },
          ]}
        />

        <MarqueeGridSection />
        <TestimonialsSection />

        {/* CTA Section */}
        <ColorFillSection
          id="cta"
          lines={[
            { text: "Don't fight" },
            { text: 'AI threats' },
            { text: 'with legacy tools.', accent: true, accentColor: '#00F0FF' },
          ]}
          showCta
        />

        <FooterSection />
      </main>
    </div>
  )
}

export default App
