export default function FooterSection() {
  const footerLinks = [
    {
      header: 'Product',
      links: ['Agent Shield', 'Deepfake Defense', 'Prompt Guard', 'Shadow AI Discovery', 'Pricing'],
    },
    {
      header: 'Resources',
      links: ['Documentation', 'API Reference', 'Security Blog', 'Threat Research', 'Status'],
    },
    {
      header: 'Company',
      links: ['About', 'Careers', 'Contact', 'Partners', 'Legal'],
    },
    {
      header: 'Connect',
      links: ['Twitter/X', 'LinkedIn', 'GitHub', 'Discord'],
    },
  ]

  return (
    <footer
      style={{
        position: 'relative',
        zIndex: 2,
        width: '100%',
        padding: '80px 24px',
        background: '#050508',
        borderTop: '1px solid rgba(255,255,255,0.04)',
      }}
    >
      <div className="mx-auto" style={{ maxWidth: '1200px' }}>
        {/* Row 1: Logo + tagline */}
        <div>
          <div
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '14px',
              letterSpacing: '0.15em',
              color: '#E8E8F0',
              textTransform: 'uppercase',
            }}
          >
            AEGIS
          </div>
          <div
            style={{
              fontFamily: 'var(--font-sans)',
              fontSize: '14px',
              color: '#6B6B80',
              marginTop: '12px',
            }}
          >
            AI-Native Cybersecurity for the Enterprise.
          </div>
        </div>

        {/* Row 2: Link columns */}
        <div
          className="grid grid-cols-2 md:grid-cols-4"
          style={{ marginTop: '48px', gap: '40px' }}
        >
          {footerLinks.map((col) => (
            <div key={col.header}>
              <div
                style={{
                  fontFamily: 'var(--font-mono)',
                  fontSize: '11px',
                  textTransform: 'uppercase',
                  color: '#6B6B80',
                  marginBottom: '16px',
                  letterSpacing: '0.08em',
                }}
              >
                {col.header}
              </div>
              <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
                {col.links.map((link) => (
                  <li key={link} style={{ marginBottom: '10px' }}>
                    <a
                      href="#"
                      className="transition-colors duration-250"
                      style={{
                        fontFamily: 'var(--font-sans)',
                        fontSize: '14px',
                        color: '#6B6B80',
                        textDecoration: 'none',
                      }}
                      onMouseEnter={(e) => {
                        e.currentTarget.style.color = '#E8E8F0'
                      }}
                      onMouseLeave={(e) => {
                        e.currentTarget.style.color = '#6B6B80'
                      }}
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Row 3: Copyright */}
        <div
          style={{
            marginTop: '64px',
            fontFamily: 'var(--font-mono)',
            fontSize: '11px',
            color: '#6B6B80',
          }}
        >
          &copy; 2026 Aegis AI, Inc. All rights reserved.
        </div>
      </div>
    </footer>
  )
}
