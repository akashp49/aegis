import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

const images = [
  '/assets/img-1.jpg',
  '/assets/img-2.jpg',
  '/assets/img-3.jpg',
  '/assets/img-4.jpg',
  '/assets/img-5.jpg',
  '/assets/img-6.jpg',
  '/assets/img-7.jpg',
  '/assets/img-8.jpg',
  '/assets/img-9.jpg',
  '/assets/img-10.jpg',
  '/assets/img-11.jpg',
  '/assets/img-12.jpg',
]

const columns = [
  [images[0], images[1]],
  [images[2], images[3]],
  [images[4], images[5]],
  [images[6], images[7]],
  [images[8], images[9]],
  [images[10], images[11]],
]

export default function MarqueeGridSection() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const gridRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (!gridRef.current) return

    const ctx = gsap.context(() => {
      gsap.fromTo(
        gridRef.current,
        { opacity: 0 },
        {
          opacity: 1,
          duration: 0.6,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 85%',
          },
        }
      )
    })

    return () => ctx.revert()
  }, [])

  return (
    <section
      ref={sectionRef}
      style={{
        position: 'relative',
        zIndex: 2,
        width: '100%',
        height: '700px',
        overflow: 'hidden',
        background: '#050508',
      }}
    >
      <div
        ref={gridRef}
        className="opacity-0"
        style={{
          width: '100%',
          height: '100%',
          display: 'grid',
          placeItems: 'center',
          padding: '2rem',
          perspective: '1000px',
          transformStyle: 'preserve-3d',
          filter: 'blur(3px)',
        }}
      >
        <div
          style={{
            height: 'auto',
            width: '100%',
            display: 'grid',
            gridTemplateColumns: 'repeat(6, 1fr)',
            gap: '2vw',
            transformStyle: 'preserve-3d',
            transform: 'rotateX(35deg) rotateY(0deg) rotateZ(10deg) scale(1.2)',
          }}
        >
          {columns.map((col, colIdx) => {
            const isEven = colIdx % 2 === 0
            return (
              <div
                key={colIdx}
                style={{
                  width: '100%',
                  display: 'flex',
                  flexDirection: isEven ? 'column' : 'column-reverse',
                  gap: '2vw',
                  animation: isEven
                    ? 'scroll-down 40s linear infinite'
                    : 'scroll-up 40s linear infinite',
                }}
              >
                {[...col, ...col].map((img, imgIdx) => (
                  <div
                    key={imgIdx}
                    style={{
                      aspectRatio: '20/15',
                      width: '100%',
                      overflow: 'hidden',
                      position: 'relative',
                      borderRadius: '4px',
                      display: 'grid',
                      placeItems: 'center',
                    }}
                  >
                    <div
                      style={{
                        position: 'relative',
                        width: '100%',
                        height: '100%',
                        backgroundImage: `url(${img})`,
                        backgroundSize: 'cover',
                        backgroundPosition: '50% 50%',
                      }}
                    />
                  </div>
                ))}
              </div>
            )
          })}
        </div>
      </div>

      <style>{`
        @keyframes scroll-down {
          from { transform: translateY(0); }
          to { transform: translateY(calc(-50%)); }
        }
        @keyframes scroll-up {
          from { transform: translateY(calc(-50%)); }
          to { transform: translateY(0); }
        }
      `}</style>
    </section>
  )
}
