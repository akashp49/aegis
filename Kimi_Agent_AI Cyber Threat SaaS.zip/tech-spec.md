# Aegis AI — Technical Specification

## Component Inventory

### Layout

| Component | Source | Reuse | Notes |
|-----------|--------|-------|-------|
| Navigation | Custom | Single | Fixed nav with backdrop-blur, smooth-scroll links |
| Footer | Custom | Single | 4-column link grid |

### Sections

| Component | Source | Notes |
|-----------|--------|-------|
| HeroSection | Custom | Full-viewport, overlays CRT canvas |
| VideoSection | Custom | 16:9 video player with caption |
| ColorFillSection | Custom (×3) | Pinned scroll, color-fill text reveal. Reused with different content |
| FeaturesSection | Custom | 3-column feature cards grid |
| MarqueeGridSection | Custom | CSS 3D perspective infinite-scroll image grid |
| TestimonialsSection | Custom | 2×2 testimonial card grid |

### Reusable Components

| Component | Source | Used By | Notes |
|-----------|--------|---------|-------|
| CRTMonitor | Custom (Three.js) | HeroSection (global bg) | 3D monitor + ASCII texture + bloom. Persistent fixed canvas |
| ColorFillLine | Custom | ColorFillSection (×3) | Dual-layer text with clip-path scroll reveal |
| FeatureCard | Custom | FeaturesSection (×3) | Icon + title + body card |
| TestimonialCard | Custom | TestimonialsSection (×4) | Quote + avatar + attribution |
| PillButton | Custom | Multiple sections | Two variants: primary (cyan) and secondary (outline) |

### Hooks

| Hook | Purpose |
|------|---------|
| useLenis | Initialize Lenis smooth scroll, connect to GSAP ScrollTrigger |

## Animation Implementation

| Animation | Library | Implementation Approach | Complexity |
|-----------|---------|------------------------|------------|
| CRT Monitor 3D Render | Three.js (raw) | Scene with PerspectiveCamera, custom FOV from viewport, EffectComposer with UnrealBloomPass, MeshStandardMaterial box geometries for frame/screen/bezel | High |
| ASCII Video Texture | Three.js + Canvas API | Hidden `<video>` element, `<canvas>` draws video frames as ASCII chars (128×96), CanvasTexture on screen mesh, updated every frame | High |
| Cursor-driven Monitor Rotation | Three.js | Mousemove normalizes cursor to [-1, 1], lerp rotation.x/y toward target in render loop (strength 0.3, lerp 0.08) | Medium |
| Hero Entrance Sequence | GSAP | Timeline with 4 staggered fade+translateY tweens (label → H1 → body → CTAs), delays 0.2–1.0s, power3.out | Medium |
| Color Fill Text Reveal (×3) | GSAP ScrollTrigger | Pinned sections (start: "top top", end: "+=150%", scrub: true). Each `.color-line` animates clipPath from `inset(0 100% 0 0)` to `inset(0 0% 0 0)` with 0.15 stagger | Medium |
| CTA Fade-in (in Section 3) | GSAP ScrollTrigger | Part of Section 3 timeline, button opacity 0→1 at scroll position 80% | Low |
| Video Section Entrance | GSAP ScrollTrigger | Fade + translateY(60px → 0), duration 1.0s, power3.out, trigger at top 80% | Low |
| Feature Cards Entrance | GSAP ScrollTrigger | Stagger fade + translateY(50px → 0), stagger 0.15s, duration 0.8s, trigger at top 80% | Low |
| Marquee Grid Entrance | GSAP ScrollTrigger | Grid container opacity 0→1, duration 0.6s, trigger at top 85% | Low |
| Testimonial Cards Entrance | GSAP ScrollTrigger | Stagger fade + translateY(40px → 0), stagger 0.12s, duration 0.8s, trigger at top 80% | Low |
| 3D Perspective Marquee | CSS only | `perspective: 1000px`, `rotateX(35deg) rotateZ(10deg) scale(1.2)`, `@keyframes` for column scroll (even: scroll-down 40s, odd: scroll-up 40s), zoom animation 4s alternate | Medium |

## State & Logic

### Three.js ↔ React Bridge
The CRT Monitor is implemented as a **raw Three.js** scene (not R3F) managed inside a React component via `useRef` and `useEffect`. A single `<canvas>` element is created and appended to a container div. The scene, camera, renderer, composer, and animation loop are initialized in `useEffect` and cleaned up on unmount. The canvas is styled with `position: fixed; inset: 0; z-index: 0`.

### ASCII Video Lifecycle
A hidden `<video>` element is created programmatically, set to `loop`, `muted`, `playsInline`, and autoplay. A second hidden `<canvas>` (128×96) generates ASCII frames. Every frame in the render loop:
1. `generateASCIIFrame()` samples video pixels, maps brightness to chars, draws on canvas
2. `screenMaterial.map.needsUpdate = true` pushes to GPU
3. Bloom composer renders

### Lenis + GSAP ScrollTrigger Sync
Lenis is initialized once at app root. Its scroll events feed into `ScrollTrigger.update` to keep GSAP scroll-driven animations synchronized with smooth scroll position. This connection must be established before any ScrollTrigger animations are created.

### ColorFillLine Architecture
Each ColorFillLine component manages its own GSAP ScrollTrigger for clip-path animation. The parent ColorFillSection adds the `pin` behavior via a separate ScrollTrigger. The two ScrollTrigger instances work together: the parent's pin holds the section in view, while each child's scrubbed clip-path animates independently with staggered `delay` offsets (0, 0.15, 0.30) to create sequential line reveals.
