import { useEffect, useRef } from 'react'
import * as THREE from 'three'
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js'
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js'
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js'

export default function CRTMonitor() {
  const containerRef = useRef<HTMLDivElement>(null)
  const videoRef = useRef<HTMLVideoElement | null>(null)
  const asciiCanvasRef = useRef<HTMLCanvasElement | null>(null)
  const screenMaterialRef = useRef<THREE.MeshBasicMaterial | null>(null)
  const currentRotationRef = useRef({ x: 0, y: 0 })
  const targetRotationRef = useRef({ x: 0, y: 0 })
  const composerRef = useRef<EffectComposer | null>(null)
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null)
  const animationFrameRef = useRef<number>(0)
  const monitorGroupRef = useRef<THREE.Group | null>(null)

  useEffect(() => {
    if (!containerRef.current) return

    // Create hidden video element
    const video = document.createElement('video')
    video.src = '/assets/vid-1.mp4'
    video.loop = true
    video.muted = true
    video.playsInline = true
    video.crossOrigin = 'anonymous'
    videoRef.current = video

    // Create hidden ASCII canvas
    const asciiCanvas = document.createElement('canvas')
    asciiCanvas.width = 128
    asciiCanvas.height = 96
    asciiCanvasRef.current = asciiCanvas

    // Scene setup
    const scene = new THREE.Scene()
    const desiredDistance = 400
    const fov = 2 * Math.atan(window.innerHeight / (2 * desiredDistance)) * (180 / Math.PI)
    const camera = new THREE.PerspectiveCamera(fov, window.innerWidth / window.innerHeight, 0.1, 1000)
    camera.position.set(0, 0, 5)

    const renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
    })
    renderer.setSize(window.innerWidth, window.innerHeight)
    renderer.setPixelRatio(Math.min(2, window.devicePixelRatio))
    renderer.domElement.style.width = '100%'
    renderer.domElement.style.height = '100%'
    renderer.domElement.style.display = 'block'
    containerRef.current.appendChild(renderer.domElement)
    rendererRef.current = renderer

    // Post-processing (Bloom)
    const composer = new EffectComposer(renderer)
    const renderPass = new RenderPass(scene, camera)
    composer.addPass(renderPass)

    const bloomPass = new UnrealBloomPass(
      new THREE.Vector2(window.innerWidth, window.innerHeight),
      0.15,
      0.5,
      0.1
    )
    composer.addPass(bloomPass)
    composerRef.current = composer

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 1.5)
    scene.add(ambientLight)

    const directionalLight = new THREE.DirectionalLight(0xffffff, 2)
    directionalLight.position.set(2, 3, 2)
    scene.add(directionalLight)

    // CRT Monitor Model
    const monitorGroup = new THREE.Group()
    monitorGroupRef.current = monitorGroup

    // 1. Frame (body)
    const frameGeometry = new THREE.BoxGeometry(3.2, 2.4, 1.0)
    const frameMaterial = new THREE.MeshStandardMaterial({
      color: 0x4a4a4a,
      roughness: 0.7,
      metalness: 0.1,
    })
    const frame = new THREE.Mesh(frameGeometry, frameMaterial)
    frame.position.set(0, 0, -0.5)
    monitorGroup.add(frame)

    // 2. Screen (display area)
    const screenGeometry = new THREE.BoxGeometry(2.9, 2.1, 0.1)
    const screenTexture = new THREE.CanvasTexture(asciiCanvas)
    screenTexture.minFilter = THREE.NearestFilter
    screenTexture.magFilter = THREE.NearestFilter

    const screenMaterial = new THREE.MeshBasicMaterial({
      map: screenTexture,
      color: 0xffffff,
    })
    screenMaterialRef.current = screenMaterial

    const screenMesh = new THREE.Mesh(screenGeometry, screenMaterial)
    screenMesh.position.set(0, 0, 0.01)
    monitorGroup.add(screenMesh)

    // 3. Bezel (front border)
    const bezelGeometry = new THREE.BoxGeometry(3.0, 2.2, 0.05)
    const bezelMaterial = new THREE.MeshStandardMaterial({
      color: 0x1a1a1a,
      roughness: 0.5,
      metalness: 0.3,
    })
    const bezel = new THREE.Mesh(bezelGeometry, bezelMaterial)
    bezel.position.set(0, 0, 0.05)
    monitorGroup.add(bezel)

    scene.add(monitorGroup)

    // Mouse tracking
    const onMouseMove = (e: MouseEvent) => {
      const normalizedX = (e.clientX / window.innerWidth - 0.5) * 2
      const normalizedY = (e.clientY / window.innerHeight - 0.5) * 2
      targetRotationRef.current.x = normalizedY * 0.3 * 0.3
      targetRotationRef.current.y = normalizedX * 0.3 * 0.3
    }
    window.addEventListener('mousemove', onMouseMove)

    // ASCII generation
    const ctx = asciiCanvas.getContext('2d')!
    const chars = ' .:-=+*#%@'

    const generateASCIIFrame = () => {
      const vid = videoRef.current
      const canvas = asciiCanvasRef.current
      if (!vid || !canvas) return
      if (vid.videoWidth === 0 || vid.videoHeight === 0) return

      canvas.width = 128
      canvas.height = 96

      ctx.drawImage(vid, 0, 0, 128, 96)

      const imageData = ctx.getImageData(0, 0, 128, 96)

      ctx.fillStyle = 'black'
      ctx.fillRect(0, 0, 128, 96)

      ctx.fillStyle = 'white'
      ctx.font = '6px monospace'

      const charWidth = ctx.measureText('M').width
      const lineHeight = 6

      for (let y = 0; y < 96; y++) {
        for (let x = 0; x < 128; x += Math.ceil(charWidth)) {
          const i = (y * 128 + x) * 4
          const brightness = (imageData.data[i] + imageData.data[i + 1] + imageData.data[i + 2]) / 3
          const charIndex = Math.floor((brightness / 255) * (chars.length - 1))
          ctx.fillText(chars[charIndex], x, y * lineHeight)
        }
      }

      if (screenMaterialRef.current) {
        screenMaterialRef.current.map!.needsUpdate = true
      }
    }

    // Resize handler
    const onResize = () => {
      const newFov = 2 * Math.atan(window.innerHeight / (2 * 400)) * (180 / Math.PI)
      camera.fov = newFov
      camera.aspect = window.innerWidth / window.innerHeight
      camera.updateProjectionMatrix()
      renderer.setSize(window.innerWidth, window.innerHeight)
      composer.setSize(window.innerWidth, window.innerHeight)
      bloomPass.resolution.set(window.innerWidth, window.innerHeight)
    }
    window.addEventListener('resize', onResize)

    // Start video
    video.play().catch(() => {
      // Autoplay might be blocked, that's okay
    })

    // Render loop
    const animate = () => {
      animationFrameRef.current = requestAnimationFrame(animate)

      generateASCIIFrame()

      // Smooth rotation
      const current = currentRotationRef.current
      const target = targetRotationRef.current
      current.x += (target.x - current.x) * 0.08
      current.y += (target.y - current.y) * 0.08

      if (monitorGroupRef.current) {
        monitorGroupRef.current.rotation.x = current.x
        monitorGroupRef.current.rotation.y = current.y
      }

      if (composerRef.current) {
        composerRef.current.render()
      }
    }
    animate()

    return () => {
      cancelAnimationFrame(animationFrameRef.current)
      window.removeEventListener('mousemove', onMouseMove)
      window.removeEventListener('resize', onResize)
      video.pause()
      video.src = ''
      renderer.dispose()
      composer.dispose()
      if (containerRef.current && renderer.domElement.parentNode === containerRef.current) {
        containerRef.current.removeChild(renderer.domElement)
      }
    }
  }, [])

  return (
    <div
      ref={containerRef}
      style={{
        position: 'fixed',
        top: 0,
        left: 0,
        width: '100%',
        height: '100%',
        zIndex: 0,
        pointerEvents: 'none',
      }}
    >
      {/* Radial gradient overlay */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          background: 'radial-gradient(ellipse at center, transparent 30%, rgba(5,5,8,0.7) 100%)',
          zIndex: 1,
          pointerEvents: 'none',
        }}
      />
    </div>
  )
}
