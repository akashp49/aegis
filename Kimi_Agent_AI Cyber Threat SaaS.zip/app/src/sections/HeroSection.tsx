import { useEffect, useRef } from 'react'
import gsap from 'gsap'

export default function HeroSection() {
  const labelRef = useRef<HTMLDivElement>(null)
  const h1Ref = useRef<HTMLHeadingElement>(null)
  const bodyRef = useRef<HTMLParagraphElement>(null)
  const ctaRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const tl = gsap.timeline()

    if (labelRef.current) {
      tl.to(labelRef.current, {
        opacity: 1,
        y: 0,
        duration: 0.8,
        ease: 'power3.out',
      }, 0.2)
    }

    if (h1Ref.current) {
      tl.to(h1Ref.current, {
        opacity: 1,
        y: 0,
        duration: 1.0,
        ease: 'power3.out',
      }, 0.4)
    }

    if (bodyRef.current) {
      tl.to(bodyRef.current, {
        opacity: 1,
        y: 0,
        duration: 0.8,
        ease: 'power3.out',
      }, 0.7)
    }

    if (ctaRef.current) {
      tl.to(ctaRef.current, {
        opacity: 1,
        y: 0,
        duration: 0.7,
        ease: 'power3.out',
      }, 1.0)
    }

    return () => {
      tl.kill()
    }
  }, [])

  return (
    <section
      id="hero"
      className="relative flex items-center justify-center"
      style={{ height: '100vh', zIndex: 1 }}
    >
      <div className="flex flex-col items-center text-center" style={{ maxWidth: '700px', padding: '0 24px' }}>
        {/* Label */}
        <div
          ref={labelRef}
          className="opacity-0"
          style={{
            fontFamily: 'var(--font-mono)',
            fontSize: '12px',
            letterSpacing: '0.12em',
            textTransform: 'uppercase',
            color: '#00F0FF',
            marginBottom: '24px',
            transform: 'translateY(20px)',
          }}
        >
          AI-NATIVE CYBER DEFENSE
        </div>

        {/* H1 */}
        <h1
          ref={h1Ref}
          className="opacity-0"
          style={{
            fontFamily: 'var(--font-sans)',
            fontSize: 'clamp(40px, 6vw, 72px)',
            fontWeight: 400,
            lineHeight: 1.05,
            letterSpacing: '-0.03em',
            color: '#E8E8F0',
            textShadow: '0 2px 30px rgba(0,0,0,0.6)',
            transform: 'translateY(30px)',
          }}
        >
          <span>The Threat Landscape</span>
          <br />
          <span>Has Changed.</span>
        </h1>

        {/* Body */}
        <p
          ref={bodyRef}
          className="opacity-0"
          style={{
            fontFamily: 'var(--font-sans)',
            fontSize: '18px',
            fontWeight: 400,
            color: '#6B6B80',
            maxWidth: '560px',
            lineHeight: 1.65,
            marginTop: '32px',
            transform: 'translateY(20px)',
          }}
        >
          88% of enterprises experienced AI-agent security incidents in 2025. Deepfakes, prompt injection, and shadow AI are the new attack surface. Aegis is the first security platform built natively for the AI era.
        </p>

        {/* CTA Row */}
        <div
          ref={ctaRef}
          className="opacity-0 flex items-center gap-4"
          style={{ marginTop: '40px', transform: 'translateY(15px)' }}
        >
          <button
            className="transition-all duration-200 cursor-pointer"
            style={{
              borderRadius: '80px',
              background: '#00F0FF',
              color: '#050508',
              padding: '14px 28px',
              fontFamily: 'var(--font-sans)',
              fontSize: '14px',
              fontWeight: 400,
              border: 'none',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = '#33F3FF'
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = '#00F0FF'
            }}
          >
            Start Free Trial
          </button>
          <button
            className="transition-all duration-200 cursor-pointer"
            style={{
              borderRadius: '80px',
              background: 'transparent',
              border: '1px solid rgba(255,255,255,0.1)',
              color: '#E8E8F0',
              padding: '14px 28px',
              fontFamily: 'var(--font-sans)',
              fontSize: '14px',
              fontWeight: 400,
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.borderColor = 'rgba(255,255,255,0.2)'
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.borderColor = 'rgba(255,255,255,0.1)'
            }}
          >
            Watch Demo
          </button>
        </div>
      </div>
    </section>
  )
}
