import { useEffect, useRef } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

const testimonials = [
  {
    quote: 'Aegis detected a prompt injection attack on our customer-facing LLM within hours of deployment. The agent security module alone paid for the entire platform.',
    name: 'Sarah Chen',
    role: 'CISO, Meridian Financial',
    avatar: '/assets/avatar-1.jpg',
  },
  {
    quote: 'We were blindsided by a deepfake voice fraud attempt targeting our finance team. Aegis flagged it in real-time. That call would have cost us $2.4 million.',
    name: 'Marcus Webb',
    role: 'VP Security, Apex Logistics',
    avatar: '/assets/avatar-2.jpg',
  },
  {
    quote: 'Shadow AI was our biggest blind spot — 200+ unsanctioned AI tools across our engineering teams. Aegis mapped our entire attack surface in 48 hours.',
    name: 'Elena Volkov',
    role: 'Director of Cybersecurity, Nortech',
    avatar: '/assets/avatar-3.jpg',
  },
  {
    quote: 'The only platform that treats AI security as its own discipline, not a bolt-on module. Aegis understands that the threat model has fundamentally changed.',
    name: 'David Park',
    role: 'CTO, Stratum Health',
    avatar: '/assets/avatar-4.jpg',
  },
]

export default function TestimonialsSection() {
  const sectionRef = useRef<HTMLDivElement>(null)
  const cardsRef = useRef<HTMLDivElement[]>([])

  useEffect(() => {
    if (!sectionRef.current) return

    const ctx = gsap.context(() => {
      cardsRef.current.forEach((card, i) => {
        if (!card) return
        gsap.fromTo(
          card,
          { opacity: 0, y: 40 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            delay: i * 0.12,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 80%',
            },
          }
        )
      })
    })

    return () => ctx.revert()
  }, [])

  return (
    <section
      ref={sectionRef}
      style={{
        position: 'relative',
        zIndex: 2,
        background: '#0A0A10',
        padding: '140px 24px',
      }}
    >
      <div className="mx-auto" style={{ maxWidth: '1200px' }}>
        {/* Section header */}
        <div className="text-center" style={{ marginBottom: '80px' }}>
          <div
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '12px',
              letterSpacing: '0.12em',
              textTransform: 'uppercase',
              color: '#00F0FF',
              marginBottom: '16px',
            }}
          >
            CUSTOMERS
          </div>
          <h2
            style={{
              fontFamily: 'var(--font-sans)',
              fontSize: 'clamp(32px, 4vw, 48px)',
              fontWeight: 400,
              lineHeight: 1.15,
              letterSpacing: '-0.02em',
              color: '#E8E8F0',
            }}
          >
            Trusted by security teams worldwide.
          </h2>
        </div>

        {/* Testimonials grid */}
        <div
          className="grid grid-cols-1 md:grid-cols-2"
          style={{ gap: '24px' }}
        >
          {testimonials.map((t, i) => (
            <div
              key={t.name}
              ref={(el) => {
                if (el) cardsRef.current[i] = el
              }}
              className="opacity-0"
              style={{
                background: '#111118',
                border: '1px solid rgba(255,255,255,0.04)',
                borderRadius: '8px',
                padding: '40px',
              }}
            >
              <p
                style={{
                  fontFamily: 'var(--font-sans)',
                  fontSize: '18px',
                  fontWeight: 400,
                  color: '#E8E8F0',
                  lineHeight: 1.6,
                  fontStyle: 'italic',
                }}
              >
                &ldquo;{t.quote}&rdquo;
              </p>
              <div className="flex items-center gap-3" style={{ marginTop: '32px' }}>
                <img
                  src={t.avatar}
                  alt={t.name}
                  style={{
                    width: '40px',
                    height: '40px',
                    borderRadius: '50%',
                    objectFit: 'cover',
                  }}
                />
                <div>
                  <div
                    style={{
                      fontFamily: 'var(--font-sans)',
                      fontSize: '14px',
                      fontWeight: 400,
                      color: '#E8E8F0',
                    }}
                  >
                    {t.name}
                  </div>
                  <div
                    style={{
                      fontFamily: 'var(--font-sans)',
                      fontSize: '13px',
                      fontWeight: 400,
                      color: '#6B6B80',
                    }}
                  >
                    {t.role}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
